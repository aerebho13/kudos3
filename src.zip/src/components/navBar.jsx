import './navBar.css';

const NavBar = () => {
    return (
        <div className='navBar'>
            <ul>
                <li><a href="#">Home</a> </li>
                <li><a href="#">Meal Plans</a> </li>
                <li><a href="#">Contact</a> </li>
            </ul>
        </div>
    );
};

export default NavBar;
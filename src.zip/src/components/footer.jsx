import './footer.css';

const Footer = () => {
    return (
        <div className='Foot'>
            <h5>
                Copyright © 2022. KUDOS
                <br />All rights reserved. Created by Aaron Erebholo.
            </h5>
        </div>
    );
};

export default Footer;